#ifndef EXEC_H
#define EXEC_H

int run_command(const char *cmd);

#endif
